#6787094 Jeffrey Amaga Phillips
#6787113 Pakin Narkjaroen 
setwd("C:/Users/Lenovo/Downloads/Lab4")


library(ggplot2)  # for plots
library(dplyr)    # for data manipulation


library(car) # for Levene’s test (variance check)
data <- read.csv("my_data.csv") 

summary_stats <- data %>%
  group_by(Group, Gender) %>%
  summarise(
    Mean = mean(Score_Count),
    Median = median(Score_Count),
    Variance = var(Score_Count),
    SD = sd(Score_Count),
    .groups = 'drop'
  )
summary_stats  # Print summary stats



shapiro_A <- shapiro.test(subset(data, Group == "Group A")$Score_Count)
shapiro_B <- shapiro.test(subset(data, Group == "Group B")$Score_Count)
shapiro_C <- shapiro.test(subset(data, Group == "Group C")$Score_Count)

shapiro_A
shapiro_B
shapiro_C

wilcox_result <- wilcox.test(Score_Count ~ Group, data = subset(data, Group %in% c("Group A", "Group B")))
wilcox_result

t_ab <- t.test(Score_Count ~ Group, data = subset(data, Group %in% c("Group A", "Group B")))
t_ac <- t.test(Score_Count ~ Group, data = subset(data, Group %in% c("Group A", "Group C")))
t_bc <- t.test(Score_Count ~ Group, data = subset(data, Group %in% c("Group B", "Group C")))

t_ab
t_ac
t_bc

t_gender <- t.test(Score_Count ~ Gender, data = subset(data, Group == "Group A"))
t_gender
#p-valueA = 0.5397
# Non-significant difference

t_genderB <- t.test(Score_Count ~ Gender, data = subset(data, Group == "Group B"))
t_genderB
#p-value = 0.0277
# significant difference

t_genderC <- t.test(Score_Count ~ Gender, data = subset(data, Group == "Group C"))
t_genderC
#p-value = 0.2094
# significant difference

levene_result <- leveneTest(Score_Count ~ Group, data = subset(data, Group %in% c("Group A", "Group B")))
levene_result

var_result <- var.test(Score_Count ~ Group, data = subset(data, Group %in% c("Group A", "Group B")))
var_result

t.test(Score_Count ~ Group, data = subset(data, Group %in% c("Group A", "Group B")), var.equal = TRUE)
